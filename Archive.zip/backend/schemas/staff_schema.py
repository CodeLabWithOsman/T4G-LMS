"""Staff schemas.

Fixes applied:
  * StaffResponse had NO `class Config: from_attributes = True`. It was
    attached to ChangePassword by mistake, so returning ORM Staff objects
    from GET /staff/ raised a serialization error. Moved to the right class.
  * StaffResponse now exposes is_default_password and status.
  * Emails normalised to lowercase; passwords have a minimum length.
  * ResetPassword now carries the signed reset_token issued by
    /staff/forgot-password instead of trusting a bare email address.
"""

from enum import Enum
from typing import Optional

from pydantic import BaseModel, EmailStr, Field, field_validator


class StaffTrackEnum(str, Enum):
    frontend = "Frontend"
    backend = "Backend"


class StaffStatusEnum(str, Enum):
    active = "Active"
    inactive = "Inactive"


class _NormalisedEmail(BaseModel):
    @field_validator("email", mode="before", check_fields=False)
    @classmethod
    def _lower(cls, v):
        return v.strip().lower() if isinstance(v, str) else v


class StaffCreate(_NormalisedEmail):
    first_name: str = Field(min_length=1, max_length=100)
    last_name: str = Field(min_length=1, max_length=100)
    email: EmailStr
    track: StaffTrackEnum

    @field_validator("first_name", "last_name", mode="before")
    @classmethod
    def _strip(cls, v):
        return v.strip() if isinstance(v, str) else v


class StaffResponse(BaseModel):
    id: str
    first_name: str
    last_name: str
    email: str
    staff_id: str
    track: StaffTrackEnum
    status: Optional[StaffStatusEnum] = None
    is_default_password: Optional[bool] = None

    class Config:
        from_attributes = True


class StaffLogin(_NormalisedEmail):
    email: EmailStr
    password: str = Field(min_length=1)


class ChangePassword(BaseModel):
    current_password: str = Field(min_length=1)
    new_password: str = Field(min_length=8, max_length=72)


class ForgotPassword(_NormalisedEmail):
    email: EmailStr


class ResetPassword(BaseModel):
    reset_token: str = Field(min_length=1)
    new_password: str = Field(min_length=8, max_length=72)
