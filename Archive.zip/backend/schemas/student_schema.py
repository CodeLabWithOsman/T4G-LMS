"""Student schemas.

Fixes applied:
  * StudentResponse now exposes is_default_password and status, which the
    frontend reads to force the change-password prompt. They were missing,
    so the value was always undefined on the client.
  * Emails are normalised to lowercase so logins are not case sensitive.
  * Passwords have a minimum length.
  * ResetPassword now carries the signed reset_token issued by
    /students/forgot-password instead of trusting a bare email address.
"""

from enum import Enum
from typing import Optional

from pydantic import BaseModel, EmailStr, Field, field_validator


class TrackEnum(str, Enum):
    frontend = "Frontend"
    backend = "Backend"


class StatusEnum(str, Enum):
    active = "Active"
    inactive = "Inactive"


class _NormalisedEmail(BaseModel):
    @field_validator("email", mode="before", check_fields=False)
    @classmethod
    def _lower(cls, v):
        return v.strip().lower() if isinstance(v, str) else v


class StudentCreate(_NormalisedEmail):
    first_name: str = Field(min_length=1, max_length=100)
    last_name: str = Field(min_length=1, max_length=100)
    email: EmailStr
    track: TrackEnum

    @field_validator("first_name", "last_name", mode="before")
    @classmethod
    def _strip(cls, v):
        return v.strip() if isinstance(v, str) else v


class StudentLogin(_NormalisedEmail):
    email: EmailStr
    password: str = Field(min_length=1)


class StudentResponse(BaseModel):
    id: str
    first_name: str
    last_name: str
    email: str
    student_id: str
    track: TrackEnum
    status: Optional[StatusEnum] = None
    is_default_password: Optional[bool] = None

    class Config:
        from_attributes = True


class ChangePassword(BaseModel):
    current_password: str = Field(min_length=1)
    new_password: str = Field(min_length=8, max_length=72)


class ForgotPassword(_NormalisedEmail):
    email: EmailStr


class ResetPassword(BaseModel):
    reset_token: str = Field(min_length=1)
    new_password: str = Field(min_length=8, max_length=72)
