"""Tech4Girls LMS API entrypoint.

Fixes applied:
  * CORS now allows local development and Cloudflare Pages preview
    deployments. Previously only three exact production origins were
    allowed, so the site broke on localhost / file:// / preview builds.
  * allow_credentials is False because the frontend authenticates with a
    Bearer token, not cookies. Keeping it True alongside a wildcard-style
    regex is rejected by browsers.
  * `expose_headers` so the frontend can read Content-Disposition on downloads.
  * Global exception handlers return JSON (never an HTML 500 page) and always
    carry CORS headers, so the frontend can parse every error.
  * IntegrityError -> 409 instead of an unhandled 500.
  * /health endpoint for uptime checks and warm-up.
"""

import logging
import os

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from sqlalchemy.exc import IntegrityError, SQLAlchemyError

from database import Base, engine

# Import every model before create_all so all tables/columns are registered.
import models.admin_model  # noqa: F401
import models.announcement_model  # noqa: F401
import models.course_model  # noqa: F401
import models.enrollment_model  # noqa: F401
import models.material_model  # noqa: F401
import models.notification_model  # noqa: F401
import models.staff_model  # noqa: F401
import models.student_model  # noqa: F401

from routes.admin_route import router as admin_router
from routes.announcement_route import router as announcement_router
from routes.courses_route import router as courses_router
from routes.enrollment_route import router as enrollment_router
from routes.material_route import router as material_router
from routes.notifications_route import router as notifications_router
from routes.staff_route import router as staff_router
from routes.students_route import router as students_router

logger = logging.getLogger("t4g")
logging.basicConfig(level=logging.INFO)

Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="Tech4Girls LMS API",
    description="A Learning Management System for Tech4Girls",
    version="1.1.0",
)

# --------------------------------------------------------------------------- #
# CORS
# --------------------------------------------------------------------------- #
ALLOWED_ORIGINS = [
    "https://t4g-lms.pages.dev",
    "https://admin-t4g-lms.pages.dev",
    "https://staff-t4g-lms.pages.dev",
    "http://localhost:3000",
    "http://localhost:5173",
    "http://localhost:5500",
    "http://localhost:8000",
    "http://localhost:8080",
    "http://127.0.0.1:3000",
    "http://127.0.0.1:5173",
    "http://127.0.0.1:5500",
    "http://127.0.0.1:8000",
    "http://127.0.0.1:8080",
]

extra = os.getenv("EXTRA_CORS_ORIGINS", "")
ALLOWED_ORIGINS += [o.strip() for o in extra.split(",") if o.strip()]

# Matches Cloudflare Pages preview builds and any localhost port.
ALLOWED_ORIGIN_REGEX = (
    r"^https://([a-z0-9-]+\.)*(t4g-lms|admin-t4g-lms|staff-t4g-lms)\.pages\.dev$"
    r"|^http://(localhost|127\.0\.0\.1)(:\d+)?$"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=ALLOWED_ORIGINS,
    allow_origin_regex=ALLOWED_ORIGIN_REGEX,
    allow_credentials=False,
    allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
    allow_headers=["*"],
    expose_headers=["Content-Disposition"],
    max_age=86400,
)


# --------------------------------------------------------------------------- #
# Error handling - always JSON, never an HTML error page
# --------------------------------------------------------------------------- #
@app.exception_handler(RequestValidationError)
async def validation_handler(request: Request, exc: RequestValidationError):
    first = exc.errors()[0] if exc.errors() else {}
    field = ".".join(str(p) for p in first.get("loc", []) if p != "body")
    message = first.get("msg", "Invalid request")
    detail = f"{field}: {message}" if field else message
    return JSONResponse(status_code=422, content={"detail": detail})


@app.exception_handler(IntegrityError)
async def integrity_handler(request: Request, exc: IntegrityError):
    logger.warning("Integrity error on %s: %s", request.url.path, exc)
    return JSONResponse(
        status_code=409,
        content={"detail": "That record already exists or conflicts with existing data."},
    )


@app.exception_handler(SQLAlchemyError)
async def sqlalchemy_handler(request: Request, exc: SQLAlchemyError):
    logger.exception("Database error on %s", request.url.path)
    return JSONResponse(
        status_code=500, content={"detail": "A database error occurred."}
    )


@app.exception_handler(Exception)
async def unhandled_handler(request: Request, exc: Exception):
    logger.exception("Unhandled error on %s", request.url.path)
    return JSONResponse(
        status_code=500, content={"detail": "An unexpected server error occurred."}
    )


# --------------------------------------------------------------------------- #
# Routers
# --------------------------------------------------------------------------- #
app.include_router(students_router)
app.include_router(courses_router)
app.include_router(admin_router)
app.include_router(staff_router)
app.include_router(enrollment_router)
app.include_router(material_router)
app.include_router(notifications_router)
app.include_router(announcement_router)


@app.get("/", tags=["Health"])
def root():
    return {"message": "Welcome to Tech4Girls LMS API", "status": "ok"}


@app.get("/health", tags=["Health"])
def health():
    return {"status": "ok"}
