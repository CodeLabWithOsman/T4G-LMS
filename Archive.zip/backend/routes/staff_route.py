"""Staff routes.

Fixes applied:
  * ADDED GET /staff/me for session revalidation (mirrors /students/me).
  * Route ordering fixed: /me, /search, /login, /change-password,
    /forgot-password and /reset-password are declared BEFORE /{staff_id},
    otherwise GET /staff/me was captured by the dynamic route and returned
    404 "Staff not found".
  * Login returns `expires_in` and a consistent payload shape.
  * reset-password now requires a signed reset token from forgot-password.
  * forgot-password no longer discloses whether an account exists.
  * Destructive routes require a staff/admin token.
"""

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session

from auth import (
    access_token_ttl_seconds,
    create_access_token,
    create_reset_token,
    get_current_principal,
    hash_password,
    require_staff_or_admin,
    verify_password,
    verify_reset_token,
)
from database import get_db
from models.staff_model import Staff
from schemas.staff_schema import (
    ChangePassword,
    ForgotPassword,
    ResetPassword,
    StaffCreate,
    StaffLogin,
    StaffResponse,
)
from services.staff_service import (
    create_staff,
    delete_staff,
    get_all_staff,
    get_staff_by_email,
    get_staff_by_id,
    search_staff,
)

router = APIRouter(prefix="/staff", tags=["Staff"])


def _staff_payload(staff: Staff) -> dict:
    return {
        "id": staff.id,
        "first_name": staff.first_name,
        "last_name": staff.last_name,
        "email": staff.email,
        "staff_id": getattr(staff, "staff_id", None),
        "track": staff.track.value if hasattr(staff.track, "value") else staff.track,
        "status": staff.status.value if hasattr(staff.status, "value") else staff.status,
        "is_default_password": bool(staff.is_default_password),
        "role": "staff",
    }


# --------------------------------------------------------------------------- #
# Static routes first
# --------------------------------------------------------------------------- #
@router.get("/me")
def read_current_staff(
    principal: dict = Depends(get_current_principal),
    db: Session = Depends(get_db),
):
    staff = db.query(Staff).filter(Staff.email == principal["email"]).first()
    if not staff:
        raise HTTPException(status_code=401, detail="Session is no longer valid")
    return _staff_payload(staff)


@router.get("/search")
def search_staff_route(
    q: str = Query(..., min_length=1),
    db: Session = Depends(get_db),
):
    return search_staff(db, q)


@router.post("/login")
def login_staff(staff: StaffLogin, db: Session = Depends(get_db)):
    email = (staff.email or "").strip().lower()
    db_staff = get_staff_by_email(db, email) if email else None
    if not db_staff or not verify_password(staff.password, db_staff.password):
        raise HTTPException(status_code=401, detail="Incorrect email or password")

    token = create_access_token(data={"sub": db_staff.email, "role": "staff"})
    return {
        "access_token": token,
        "token_type": "bearer",
        "expires_in": access_token_ttl_seconds(),
        "role": "staff",
        "staff": _staff_payload(db_staff),
    }


@router.put("/change-password")
def change_staff_password(
    passwords: ChangePassword,
    principal: dict = Depends(get_current_principal),
    db: Session = Depends(get_db),
):
    staff = db.query(Staff).filter(Staff.email == principal["email"]).first()
    if not staff:
        raise HTTPException(status_code=404, detail="Staff not found")
    if not verify_password(passwords.current_password, staff.password):
        raise HTTPException(status_code=401, detail="Current password is incorrect")
    if passwords.current_password == passwords.new_password:
        raise HTTPException(
            status_code=400, detail="New password must be different from the current one"
        )
    staff.password = hash_password(passwords.new_password)
    staff.is_default_password = False
    db.commit()
    return {"message": "Password changed successfully"}


@router.post("/forgot-password")
def staff_forgot_password(data: ForgotPassword, db: Session = Depends(get_db)):
    email = (data.email or "").strip().lower()
    staff = get_staff_by_email(db, email)
    if not staff:
        return {
            "message": "If an account exists for that email, a reset link has been issued.",
            "email": email,
            "reset_token": None,
        }
    return {
        "message": "If an account exists for that email, a reset link has been issued.",
        "email": staff.email,
        "reset_token": create_reset_token(staff.email, "staff"),
    }


@router.post("/reset-password")
def staff_reset_password(data: ResetPassword, db: Session = Depends(get_db)):
    email = verify_reset_token(data.reset_token or "", "staff")
    if not email:
        raise HTTPException(
            status_code=400, detail="This reset link is invalid or has expired"
        )
    staff = db.query(Staff).filter(Staff.email == email).first()
    if not staff:
        raise HTTPException(status_code=404, detail="Staff not found")
    staff.password = hash_password(data.new_password)
    staff.is_default_password = False
    db.commit()
    return {"message": "Password reset successfully"}


# --------------------------------------------------------------------------- #
# Collection + dynamic routes
# --------------------------------------------------------------------------- #
@router.get("/", response_model=list[StaffResponse])
def read_staff(db: Session = Depends(get_db)):
    return get_all_staff(db)


@router.post("/", response_model=StaffResponse, status_code=201)
def add_staff(staff: StaffCreate, db: Session = Depends(get_db)):
    existing = get_staff_by_email(db, (staff.email or "").strip().lower())
    if existing:
        raise HTTPException(
            status_code=400, detail="A staff member with this email already exists"
        )
    return create_staff(db, staff)


@router.get("/{staff_id}", response_model=StaffResponse)
def read_staff_member(staff_id: str, db: Session = Depends(get_db)):
    staff = get_staff_by_id(db, staff_id)
    if not staff:
        raise HTTPException(status_code=404, detail="Staff not found")
    return staff


@router.delete("/{staff_id}")
def remove_staff(
    staff_id: str,
    _: dict = Depends(require_staff_or_admin),
    db: Session = Depends(get_db),
):
    staff = delete_staff(db, staff_id)
    if not staff:
        raise HTTPException(status_code=404, detail="Staff not found")
    return {"message": "Staff deleted successfully"}
