"""Announcement routes.

Fixes applied:
  * Notification message had a leading space: f" {title}: {message}".
  * Fanning out to every student did one db.add per student; now a bulk
    insert, so posting to a large cohort does not time out.
  * Creating/deleting an announcement requires a staff or admin token.
  * Listing is paginated so the dashboard does not fetch everything.
"""

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session

from auth import require_staff_or_admin
from database import get_db
from models.announcement_model import Announcement
from models.notification_model import Notification
from models.student_model import Student
from schemas.announcement_schema import AnnouncementCreate, AnnouncementResponse

router = APIRouter(prefix="/announcements", tags=["Announcements"])


@router.get("/", response_model=list[AnnouncementResponse])
def get_announcements(
    limit: int = Query(100, ge=1, le=500),
    offset: int = Query(0, ge=0),
    db: Session = Depends(get_db),
):
    return (
        db.query(Announcement)
        .order_by(Announcement.created_at.desc())
        .offset(offset)
        .limit(limit)
        .all()
    )


@router.post("/", response_model=AnnouncementResponse, status_code=201)
def create_announcement(
    data: AnnouncementCreate,
    _: dict = Depends(require_staff_or_admin),
    db: Session = Depends(get_db),
):
    announcement = Announcement(
        title=data.title.strip(),
        message=data.message.strip(),
        posted_by=data.posted_by,
    )
    db.add(announcement)
    db.commit()
    db.refresh(announcement)

    student_ids = [row[0] for row in db.query(Student.id).all()]
    if student_ids:
        message = announcement.title + ": " + announcement.message
        db.bulk_save_objects(
            [Notification(student_id=sid, message=message) for sid in student_ids]
        )
        db.commit()

    return announcement


@router.delete("/{announcement_id}")
def delete_announcement(
    announcement_id: str,
    _: dict = Depends(require_staff_or_admin),
    db: Session = Depends(get_db),
):
    announcement = (
        db.query(Announcement).filter(Announcement.id == announcement_id).first()
    )
    if not announcement:
        raise HTTPException(status_code=404, detail="Announcement not found")
    db.delete(announcement)
    db.commit()
    return {"message": "Announcement deleted successfully"}
