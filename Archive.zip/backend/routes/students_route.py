"""Student routes.

Fixes applied:
  * ADDED GET /students/me. The frontend session module revalidates against
    this endpoint; it did not exist, so every revalidation returned 404/401
    and the user was silently logged out. This was the root cause of the
    "it logs me out on refresh" bug.
  * Login now returns `expires_in` so the frontend can store a real expiry.
  * Duplicate email on create returns 400 instead of an unhandled 500.
  * reset-password now REQUIRES a signed reset token from forgot-password.
    Previously anyone could reset any account knowing only an email address.
  * forgot-password no longer leaks whether an account exists.
  * Static paths are declared before /{student_id} so they are not swallowed.
  * Removed duplicate imports and the unused OAuth2PasswordBearer.
"""

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session

from auth import (
    create_access_token,
    create_reset_token,
    access_token_ttl_seconds,
    get_current_principal,
    hash_password,
    require_staff_or_admin,
    verify_password,
    verify_reset_token,
)
from database import get_db
from models.student_model import Student
from schemas.student_schema import (
    ChangePassword,
    ForgotPassword,
    ResetPassword,
    StudentCreate,
    StudentLogin,
    StudentResponse,
)
from services.student_service import (
    create_student,
    delete_student,
    get_all_students,
    get_student_by_id,
    search_students,
)

router = APIRouter(prefix="/students", tags=["Students"])


def _student_payload(student: Student) -> dict:
    return {
        "id": student.id,
        "first_name": student.first_name,
        "last_name": student.last_name,
        "email": student.email,
        "student_id": student.student_id,
        "track": student.track.value if hasattr(student.track, "value") else student.track,
        "status": student.status.value if hasattr(student.status, "value") else student.status,
        "is_default_password": bool(student.is_default_password),
        "role": "student",
    }


# --------------------------------------------------------------------------- #
# Static routes first - these must not be captured by /{student_id}
# --------------------------------------------------------------------------- #
@router.get("/me")
def read_current_student(
    principal: dict = Depends(get_current_principal),
    db: Session = Depends(get_db),
):
    """Session revalidation endpoint used by the frontend on every page load."""
    student = db.query(Student).filter(Student.email == principal["email"]).first()
    if not student:
        raise HTTPException(status_code=401, detail="Session is no longer valid")
    return _student_payload(student)


@router.get("/search")
def search_students_route(
    q: str = Query(..., min_length=1),
    db: Session = Depends(get_db),
):
    return search_students(db, q)


@router.post("/login")
def login_student(student: StudentLogin, db: Session = Depends(get_db)):
    email = (student.email or "").strip().lower()
    db_student = (
        db.query(Student).filter(Student.email.ilike(email)).first() if email else None
    )
    # Same message for both failures so we do not reveal which emails exist.
    if not db_student or not verify_password(student.password, db_student.password):
        raise HTTPException(status_code=401, detail="Incorrect email or password")

    token = create_access_token(data={"sub": db_student.email, "role": "student"})
    return {
        "access_token": token,
        "token_type": "bearer",
        "expires_in": access_token_ttl_seconds(),
        "role": "student",
        "student": _student_payload(db_student),
    }


@router.put("/change-password")
def change_password(
    passwords: ChangePassword,
    principal: dict = Depends(get_current_principal),
    db: Session = Depends(get_db),
):
    student = db.query(Student).filter(Student.email == principal["email"]).first()
    if not student:
        raise HTTPException(status_code=404, detail="Student not found")
    if not verify_password(passwords.current_password, student.password):
        raise HTTPException(status_code=401, detail="Current password is incorrect")
    if passwords.current_password == passwords.new_password:
        raise HTTPException(
            status_code=400, detail="New password must be different from the current one"
        )
    student.password = hash_password(passwords.new_password)
    student.is_default_password = False
    db.commit()
    return {"message": "Password changed successfully"}


@router.post("/forgot-password")
def forgot_password(data: ForgotPassword, db: Session = Depends(get_db)):
    email = (data.email or "").strip().lower()
    student = db.query(Student).filter(Student.email.ilike(email)).first()
    if not student:
        # Do not disclose whether the account exists.
        return {
            "message": "If an account exists for that email, a reset link has been issued.",
            "email": email,
            "reset_token": None,
        }
    return {
        "message": "If an account exists for that email, a reset link has been issued.",
        "email": student.email,
        "reset_token": create_reset_token(student.email, "student"),
    }


@router.post("/reset-password")
def reset_password(data: ResetPassword, db: Session = Depends(get_db)):
    email = verify_reset_token(data.reset_token or "", "student")
    if not email:
        raise HTTPException(
            status_code=400, detail="This reset link is invalid or has expired"
        )
    # The token, not the request body, decides whose password changes.
    student = db.query(Student).filter(Student.email == email).first()
    if not student:
        raise HTTPException(status_code=404, detail="Student not found")
    student.password = hash_password(data.new_password)
    student.is_default_password = False
    db.commit()
    return {"message": "Password reset successfully"}


# --------------------------------------------------------------------------- #
# Collection + dynamic routes
# --------------------------------------------------------------------------- #
@router.get("/", response_model=list[StudentResponse])
def read_students(db: Session = Depends(get_db)):
    return get_all_students(db)


@router.post("/", response_model=StudentResponse, status_code=201)
def add_student(student: StudentCreate, db: Session = Depends(get_db)):
    email = (student.email or "").strip().lower()
    existing = db.query(Student).filter(Student.email.ilike(email)).first()
    if existing:
        raise HTTPException(
            status_code=400, detail="A student with this email already exists"
        )
    return create_student(db, student)


@router.get("/{student_id}", response_model=StudentResponse)
def read_student(student_id: str, db: Session = Depends(get_db)):
    student = get_student_by_id(db, student_id)
    if not student:
        raise HTTPException(status_code=404, detail="Student not found")
    return student


@router.delete("/{student_id}")
def remove_student(
    student_id: str,
    _: dict = Depends(require_staff_or_admin),
    db: Session = Depends(get_db),
):
    student = delete_student(db, student_id)
    if not student:
        raise HTTPException(status_code=404, detail="Student not found")
    return {"message": "Student deleted successfully"}
