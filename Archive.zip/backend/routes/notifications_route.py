"""Notification routes.

Fixes applied:
  * Static/longer paths are declared before /{notif_id}/read so route
    matching order can never become ambiguous as this file grows.
  * mark_all_read used `Notification.is_read == False` with the default
    query semantics; it now also handles rows where is_read is NULL, which
    were previously never marked as read and kept the unread badge stuck.
  * update() now passes synchronize_session=False, avoiding a stale-session
    warning/error under SQLAlchemy 2.
  * Endpoints return the affected count so the frontend can update the badge
    without a second request.
  * Listing is paginated and supports unread_only.
"""

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import or_
from sqlalchemy.orm import Session

from database import get_db
from models.notification_model import Notification
from schemas.notification_schema import NotificationCreate, NotificationResponse

router = APIRouter(prefix="/notifications", tags=["Notifications"])


@router.get("/student/{student_id}", response_model=list[NotificationResponse])
def get_student_notifications(
    student_id: str,
    unread_only: bool = Query(False),
    limit: int = Query(100, ge=1, le=500),
    offset: int = Query(0, ge=0),
    db: Session = Depends(get_db),
):
    q = db.query(Notification).filter(Notification.student_id == student_id)
    if unread_only:
        q = q.filter(or_(Notification.is_read == False, Notification.is_read.is_(None)))  # noqa: E712
    return (
        q.order_by(Notification.created_at.desc()).offset(offset).limit(limit).all()
    )


@router.put("/student/{student_id}/read-all")
def mark_all_read(student_id: str, db: Session = Depends(get_db)):
    updated = (
        db.query(Notification)
        .filter(
            Notification.student_id == student_id,
            or_(Notification.is_read == False, Notification.is_read.is_(None)),  # noqa: E712
        )
        .update({"is_read": True}, synchronize_session=False)
    )
    db.commit()
    return {"message": "All marked as read", "updated": updated}


@router.post("/", response_model=NotificationResponse, status_code=201)
def create_notification(data: NotificationCreate, db: Session = Depends(get_db)):
    notif = Notification(student_id=data.student_id, message=data.message)
    db.add(notif)
    db.commit()
    db.refresh(notif)
    return notif


@router.put("/{notif_id}/read")
def mark_as_read(notif_id: str, db: Session = Depends(get_db)):
    notif = db.query(Notification).filter(Notification.id == notif_id).first()
    if not notif:
        raise HTTPException(status_code=404, detail="Notification not found")
    notif.is_read = True
    db.commit()
    return {"message": "Marked as read", "id": notif_id}
