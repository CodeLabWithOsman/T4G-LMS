"""Material routes.

Fixes applied:
  * Download/preview hardcoded media_type="application/pdf" for EVERY file.
    A .docx, .png or .zip was served as a PDF, so the browser refused to
    open it and downloads arrived corrupted. The MIME type is now derived
    from the stored filename.
  * Content-Disposition filenames are quoted and RFC 5987 encoded. An
    unquoted filename containing a space or comma truncated the download
    name or produced an invalid header.
  * Preview only renders inline for types a browser can actually display;
    everything else falls back to attachment instead of showing binary junk.
  * Corrupt/invalid base64 returns 422 instead of an unhandled 500.
  * Upload/delete require a staff or admin token.
"""

import base64
import mimetypes
from urllib.parse import quote

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import Response
from sqlalchemy.orm import Session

from auth import require_staff_or_admin
from database import get_db
from schemas.material_schema import MaterialCreate, MaterialResponse
from services.material_service import (
    create_material,
    delete_material,
    get_material_by_id,
    get_materials_by_course,
)

router = APIRouter(prefix="/materials", tags=["Materials"])

INLINE_TYPES = {
    "application/pdf",
    "image/png",
    "image/jpeg",
    "image/gif",
    "image/webp",
    "image/svg+xml",
    "text/plain",
}


def _guess_media_type(file_name: str) -> str:
    guessed, _ = mimetypes.guess_type(file_name or "")
    return guessed or "application/octet-stream"


def _content_disposition(disposition: str, file_name: str) -> str:
    safe = (file_name or "download").replace('"', "")
    return disposition + '; filename="' + safe + "\"; filename*=UTF-8''" + quote(safe)


def _decode(material) -> bytes:
    try:
        return base64.b64decode(material.file_data, validate=False)
    except Exception:
        raise HTTPException(
            status_code=422, detail="This file is corrupted and cannot be served"
        )


@router.get("/course/{course_id}", response_model=list[MaterialResponse])
def get_course_materials(course_id: str, db: Session = Depends(get_db)):
    return get_materials_by_course(db, course_id)


@router.post("/", response_model=MaterialResponse, status_code=201)
def upload_material(
    material: MaterialCreate,
    _: dict = Depends(require_staff_or_admin),
    db: Session = Depends(get_db),
):
    return create_material(db, material)


@router.get("/download/{material_id}")
def download_material(material_id: str, db: Session = Depends(get_db)):
    material = get_material_by_id(db, material_id)
    if not material:
        raise HTTPException(status_code=404, detail="Material not found")

    file_bytes = _decode(material)
    return Response(
        content=file_bytes,
        media_type=_guess_media_type(material.file_name),
        headers={
            "Content-Disposition": _content_disposition(
                "attachment", material.file_name
            ),
            "Content-Length": str(len(file_bytes)),
            "Cache-Control": "private, max-age=0, must-revalidate",
        },
    )


@router.get("/preview/{material_id}")
def preview_material(material_id: str, db: Session = Depends(get_db)):
    material = get_material_by_id(db, material_id)
    if not material:
        raise HTTPException(status_code=404, detail="Material not found")

    file_bytes = _decode(material)
    media_type = _guess_media_type(material.file_name)
    disposition = "inline" if media_type in INLINE_TYPES else "attachment"

    return Response(
        content=file_bytes,
        media_type=media_type,
        headers={
            "Content-Disposition": _content_disposition(
                disposition, material.file_name
            ),
            "Content-Length": str(len(file_bytes)),
            "Cache-Control": "private, max-age=0, must-revalidate",
        },
    )


@router.delete("/{material_id}")
def remove_material(
    material_id: str,
    _: dict = Depends(require_staff_or_admin),
    db: Session = Depends(get_db),
):
    material = delete_material(db, material_id)
    if not material:
        raise HTTPException(status_code=404, detail="Material not found")
    return {"message": "Material deleted successfully"}
