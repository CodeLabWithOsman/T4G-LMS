"""Admin routes.

Fixes applied:
  * The admin login token had NO role claim, so admin tokens were treated as
    student tokens and admin-only guards could never work. It now includes
    role="admin".
  * ADDED GET /admin/me for session revalidation (mirrors /students/me).
  * Login returns `expires_in` plus an `admin` object so the frontend can
    render the signed-in identity without a second request.
  * Login failures return one generic message and 401 (previously a 404 on an
    unknown email disclosed which addresses are registered).
  * /register is now protected. Previously anyone on the internet could POST
    to it and create a full administrator account. It is open only while no
    admin exists yet (first-run bootstrap); after that it requires an
    existing admin token.
"""

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, EmailStr, Field
from sqlalchemy.orm import Session

from auth import (
    access_token_ttl_seconds,
    create_access_token,
    get_current_principal,
    hash_password,
    verify_password,
)
from database import get_db
from models.admin_model import Admin

router = APIRouter(prefix="/admin", tags=["Admin"])


class AdminCreate(BaseModel):
    email: EmailStr
    password: str = Field(min_length=8)


class AdminLogin(BaseModel):
    email: EmailStr
    password: str


def _admin_payload(admin: Admin) -> dict:
    return {"id": admin.id, "email": admin.email, "role": "admin"}


@router.get("/me")
def read_current_admin(
    principal: dict = Depends(get_current_principal),
    db: Session = Depends(get_db),
):
    if principal["role"] != "admin":
        raise HTTPException(status_code=403, detail="Administrator access required")
    admin = db.query(Admin).filter(Admin.email == principal["email"]).first()
    if not admin:
        raise HTTPException(status_code=401, detail="Session is no longer valid")
    return _admin_payload(admin)


@router.post("/register", status_code=201)
def register_admin(
    admin: AdminCreate,
    request_principal: dict = Depends(get_current_principal),
    db: Session = Depends(get_db),
):
    if request_principal["role"] != "admin":
        raise HTTPException(status_code=403, detail="Administrator access required")

    email = admin.email.strip().lower()
    existing = db.query(Admin).filter(Admin.email.ilike(email)).first()
    if existing:
        raise HTTPException(status_code=400, detail="Email already exists")

    new_admin = Admin(email=email, password=hash_password(admin.password))
    db.add(new_admin)
    db.commit()
    db.refresh(new_admin)
    return {"message": "Admin registered successfully", "admin": _admin_payload(new_admin)}


@router.post("/bootstrap", status_code=201)
def bootstrap_admin(admin: AdminCreate, db: Session = Depends(get_db)):
    """Create the very first administrator. Refuses once one exists."""
    if db.query(Admin).first():
        raise HTTPException(
            status_code=403,
            detail="An administrator already exists. Sign in and use /admin/register.",
        )
    email = admin.email.strip().lower()
    new_admin = Admin(email=email, password=hash_password(admin.password))
    db.add(new_admin)
    db.commit()
    db.refresh(new_admin)
    return {"message": "Admin registered successfully", "admin": _admin_payload(new_admin)}


@router.post("/login")
def login_admin(admin: AdminLogin, db: Session = Depends(get_db)):
    email = (admin.email or "").strip().lower()
    db_admin = db.query(Admin).filter(Admin.email.ilike(email)).first() if email else None
    if not db_admin or not verify_password(admin.password, db_admin.password):
        raise HTTPException(status_code=401, detail="Incorrect email or password")

    token = create_access_token(data={"sub": db_admin.email, "role": "admin"})
    return {
        "access_token": token,
        "token_type": "bearer",
        "expires_in": access_token_ttl_seconds(),
        "role": "admin",
        "admin": _admin_payload(db_admin),
    }
