"""Enrollment routes.

Fixes applied:
  * datetime.utcnow() is deprecated and produced a naive timestamp that did
    not match the timezone-aware values written elsewhere. Now uses
    datetime.now(timezone.utc).
  * Removed the emoji from the completion notification message.
  * Marking an already-completed enrollment complete no longer creates a
    duplicate notification every time the button is pressed.
  * The notification now names the course instead of saying "a course".
  * Imports moved to module scope (they were inside the handler).
  * GET /enrollments/course/{id} returns the enrollment rows alongside the
    count; the frontend needs the rows, not just a number.
"""

from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from database import get_db
from models.course_model import Course
from models.enrollment_model import Enrollment
from models.notification_model import Notification
from schemas.enrollment_schema import EnrollmentCreate, EnrollmentResponse
from services.enrollment_service import (
    enroll_student,
    get_enrollments_by_course,
    get_enrollments_by_student,
    unenroll_student,
)

router = APIRouter(prefix="/enrollments", tags=["Enrollments"])


@router.post("/", response_model=EnrollmentResponse, status_code=201)
def enroll(enrollment: EnrollmentCreate, db: Session = Depends(get_db)):
    result = enroll_student(db, enrollment)
    if not result:
        raise HTTPException(
            status_code=400, detail="Student already enrolled in this course"
        )
    return result


@router.get("/course/{course_id}")
def get_course_enrollments(course_id: str, db: Session = Depends(get_db)):
    enrollments = get_enrollments_by_course(db, course_id)
    return {
        "course_id": course_id,
        "enrolled_students": len(enrollments),
        "enrollments": enrollments,
    }


@router.get("/student/{student_id}")
def get_student_enrollments(student_id: str, db: Session = Depends(get_db)):
    return get_enrollments_by_student(db, student_id)


@router.delete("/")
def unenroll(student_id: str, course_id: str, db: Session = Depends(get_db)):
    result = unenroll_student(db, student_id, course_id)
    if not result:
        raise HTTPException(status_code=404, detail="Enrollment not found")
    return {"message": "Student unenrolled successfully"}


@router.put("/{enrollment_id}/complete")
def mark_complete(enrollment_id: str, db: Session = Depends(get_db)):
    enrollment = db.query(Enrollment).filter(Enrollment.id == enrollment_id).first()
    if not enrollment:
        raise HTTPException(status_code=404, detail="Enrollment not found")

    if enrollment.is_completed:
        return {"message": "Course already marked as complete"}

    enrollment.is_completed = True
    enrollment.completed_at = datetime.now(timezone.utc)

    course = db.query(Course).filter(Course.id == enrollment.course_id).first()
    course_title = (
        course.title if course and getattr(course, "title", None) else "your course"
    )

    db.add(
        Notification(
            student_id=enrollment.student_id,
            message="Congratulations. You have completed " + course_title + ".",
        )
    )
    db.commit()
    db.refresh(enrollment)

    return {"message": "Course marked as complete"}
