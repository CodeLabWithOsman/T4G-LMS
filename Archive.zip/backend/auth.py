"""Authentication utilities for Tech4Girls LMS.

Fixes applied:
  * SECRET_KEY / ALGORITHM / expiry no longer crash when env vars are absent.
  * Long-lived tokens (default 30 days) so users are NOT logged out while
    they keep using the site. Only an explicit logout clears the session.
  * Tokens carry a role claim, and dependencies enforce it, so a student
    token can no longer call admin/staff-only endpoints.
  * Timezone-aware datetimes (datetime.utcnow() is deprecated).
  * Separate, short-lived, single-purpose password-reset tokens.
"""

import os
import secrets
from datetime import datetime, timedelta, timezone
from typing import Optional

from dotenv import load_dotenv
from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from jose import JWTError, jwt
from passlib.context import CryptContext

load_dotenv()


def _int_env(name: str, default: int) -> int:
    raw = os.getenv(name)
    if raw is None or str(raw).strip() == "":
        return default
    try:
        return int(str(raw).strip())
    except ValueError:
        return default


SECRET_KEY = os.getenv("SECRET_KEY") or secrets.token_urlsafe(64)
ALGORITHM = os.getenv("ALGORITHM") or "HS256"

ACCESS_TOKEN_EXPIRE_MINUTES = _int_env("ACCESS_TOKEN_EXPIRE_MINUTES", 60 * 24 * 30)
RESET_TOKEN_EXPIRE_MINUTES = _int_env("RESET_TOKEN_EXPIRE_MINUTES", 30)

bearer_scheme = HTTPBearer(auto_error=False)

pwd_context = CryptContext(
    schemes=["bcrypt"], deprecated="auto", bcrypt__truncate_error=False
)

CREDENTIALS_ERROR = HTTPException(
    status_code=status.HTTP_401_UNAUTHORIZED,
    detail="Could not validate credentials",
    headers={"WWW-Authenticate": "Bearer"},
)


def hash_password(password: str) -> str:
    return pwd_context.hash(password[:72])


def verify_password(plain_password: str, hashed_password: str) -> bool:
    if not plain_password or not hashed_password:
        return False
    try:
        return pwd_context.verify(plain_password[:72], hashed_password)
    except Exception:
        return False


def access_token_ttl_seconds() -> int:
    return ACCESS_TOKEN_EXPIRE_MINUTES * 60


def create_access_token(data: dict, expires_minutes: Optional[int] = None) -> str:
    to_encode = data.copy()
    minutes = expires_minutes or ACCESS_TOKEN_EXPIRE_MINUTES
    now = datetime.now(timezone.utc)
    to_encode.update({
        "exp": now + timedelta(minutes=minutes),
        "iat": now,
        "type": "access",
    })
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)


def decode_token(token: str) -> Optional[dict]:
    try:
        return jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
    except JWTError:
        return None


def verify_token(token: str) -> Optional[str]:
    payload = decode_token(token)
    if not payload or payload.get("type") != "access":
        return None
    return payload.get("sub")


def create_reset_token(email: str, role: str) -> str:
    now = datetime.now(timezone.utc)
    payload = {
        "sub": email,
        "role": role,
        "type": "reset",
        "iat": now,
        "exp": now + timedelta(minutes=RESET_TOKEN_EXPIRE_MINUTES),
        "jti": secrets.token_urlsafe(8),
    }
    return jwt.encode(payload, SECRET_KEY, algorithm=ALGORITHM)


def verify_reset_token(token: str, expected_role: str) -> Optional[str]:
    payload = decode_token(token)
    if not payload:
        return None
    if payload.get("type") != "reset":
        return None
    if payload.get("role") != expected_role:
        return None
    return payload.get("sub")


def get_current_principal(
    credentials: Optional[HTTPAuthorizationCredentials] = Depends(bearer_scheme),
) -> dict:
    if credentials is None or not credentials.credentials:
        raise CREDENTIALS_ERROR
    payload = decode_token(credentials.credentials)
    if not payload or payload.get("type") != "access":
        raise CREDENTIALS_ERROR
    email = payload.get("sub")
    if not email:
        raise CREDENTIALS_ERROR
    return {"email": email, "role": payload.get("role") or "student"}


def get_current_user(principal: dict = Depends(get_current_principal)) -> str:
    return principal["email"]


def require_role(*allowed_roles: str):
    def _guard(principal: dict = Depends(get_current_principal)) -> dict:
        if principal["role"] not in allowed_roles:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="You do not have permission to perform this action",
            )
        return principal
    return _guard


require_student = require_role("student")
require_admin = require_role("admin")
require_staff_or_admin = require_role("staff", "admin")
