/**
 * Tech4Girls LMS - API configuration.
 *
 * Loaded first on every page, before session.js and before any inline script.
 *
 * Why this file exists:
 *  1. Every page hardcoded BASE_URL = "https://t4g-lms-backend.fly.dev", so
 *     running the frontend locally still talked to production. You could not
 *     test against `uvicorn main:app --reload` without hand-editing 7 files.
 *  2. profile.html and student-dashboard.html USE BASE_URL but never declare
 *     it - they relied on session.js leaking it as a global. Defining it here
 *     makes that dependency explicit instead of accidental.
 *
 * Override order:
 *   window.API_BASE_URL set before this script  ->  wins
 *   ?api=... in the query string                ->  wins (and is remembered)
 *   localhost / 127.0.0.1 / file://             ->  http://127.0.0.1:8000
 *   anything else                               ->  production
 */
(function (global) {
  "use strict";

  var PRODUCTION = "https://t4g-lms-backend.fly.dev";
  var LOCAL = "http://127.0.0.1:8000";
  var STORAGE_KEY = "t4g_api_base_url";

  function stored(key) {
    try {
      return global.localStorage.getItem(key);
    } catch (e) {
      return null;
    }
  }

  function remember(key, value) {
    try {
      global.localStorage.setItem(key, value);
    } catch (e) {
      /* ignore */
    }
  }

  function trimSlash(url) {
    return String(url).replace(/\/+$/, "");
  }

  function resolve() {
    // 1. Explicit override set by the page before this script loaded.
    if (global.API_BASE_URL) return trimSlash(global.API_BASE_URL);

    // 2. ?api=http://... for quick manual testing against any backend.
    try {
      var q = new URLSearchParams(global.location.search).get("api");
      if (q) {
        remember(STORAGE_KEY, trimSlash(q));
        return trimSlash(q);
      }
    } catch (e) {
      /* ignore */
    }

    // 3. A previously chosen override sticks across navigation.
    var saved = stored(STORAGE_KEY);
    if (saved) return trimSlash(saved);

    // 4. Auto-detect local development.
    var host = global.location.hostname;
    if (
      global.location.protocol === "file:" ||
      host === "localhost" ||
      host === "127.0.0.1" ||
      host === "0.0.0.0" ||
      host === "[::1]"
    ) {
      return LOCAL;
    }

    // 5. Deployed.
    return PRODUCTION;
  }

  var resolved = resolve();

  // Both names are exposed. BASE_URL is what the existing page scripts read.
  global.API_BASE_URL = resolved;
  global.BASE_URL = resolved;
})(window);
