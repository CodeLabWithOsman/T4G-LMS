/**
 * Tech4Girls LMS - unified session layer (student / staff / admin).
 *
 * Bugs this fixes:
 *  1. "It logs me out on its own."
 *     The old code revalidated against /students/me, which did not exist on
 *     the backend. Every check returned 404/401 and wiped the session. The
 *     endpoint now exists, AND a failed check no longer destroys the session
 *     unless the server explicitly answers 401/403. Network errors, offline,
 *     cold starts and 5xx are ignored.
 *  2. "Refreshing bounces me to the login page."
 *     Auth is now resolved from localStorage synchronously before paint, so a
 *     valid session renders the page immediately with no redirect.
 *  3. "The login page flashes."
 *     See auth-guard.js: the document is hidden until the guard decides, and
 *     the decision is synchronous. Revalidation happens afterwards in the
 *     background and never blocks rendering.
 *  4. Sliding expiry: any activity extends the stored session, so an active
 *     user is never signed out. Only an explicit logout clears it.
 *  5. Admin and staff pages previously used raw localStorage with no shared
 *     logic and redirected to files that do not exist.
 */
(function (global) {
  "use strict";

  var BASE_URL = global.BASE_URL || "https://t4g-lms-backend.fly.dev";

  // 30 days, matching the backend token lifetime.
  var DEFAULT_TTL_MS = 30 * 24 * 60 * 60 * 1000;

  var ROLES = {
    student: {
      key: "student",
      tokenKey: "student_token",
      userKey: "student_user",
      expiryKey: "student_token_expiry",
      lastPageKey: "student_last_page",
      meEndpoint: "/students/me",
      loginPage: "login.html",
      homePage: "student-dashboard.html",
      userField: "student"
    },
    staff: {
      key: "staff",
      tokenKey: "staff_token",
      userKey: "staff_user",
      expiryKey: "staff_token_expiry",
      lastPageKey: "staff_last_page",
      meEndpoint: "/staff/me",
      loginPage: "index.html",
      homePage: "staff-dashboard.html",
      userField: "staff"
    },
    admin: {
      key: "admin",
      tokenKey: "admin_token",
      userKey: "admin_user",
      expiryKey: "admin_token_expiry",
      lastPageKey: "admin_last_page",
      meEndpoint: "/admin/me",
      loginPage: "index.html",
      homePage: "admin-dashboard.html",
      userField: "admin"
    }
  };

  /* ------------------------------------------------------------------ */
  /* Storage helpers - never throw, even in private mode                 */
  /* ------------------------------------------------------------------ */
  function read(key) {
    try {
      return global.localStorage.getItem(key);
    } catch (e) {
      return null;
    }
  }

  function write(key, value) {
    try {
      global.localStorage.setItem(key, value);
      return true;
    } catch (e) {
      return false;
    }
  }

  function remove(key) {
    try {
      global.localStorage.removeItem(key);
    } catch (e) {
      /* ignore */
    }
  }

  function parseJSON(raw) {
    if (!raw || raw === "undefined" || raw === "null") return null;
    try {
      return JSON.parse(raw);
    } catch (e) {
      return null;
    }
  }

  /* ------------------------------------------------------------------ */
  /* Role resolution                                                     */
  /* ------------------------------------------------------------------ */
  function resolveRole(explicit) {
    if (explicit && ROLES[explicit]) return ROLES[explicit];
    if (global.SESSION_ROLE && ROLES[global.SESSION_ROLE]) {
      return ROLES[global.SESSION_ROLE];
    }
    var path = global.location.pathname.toLowerCase();
    if (path.indexOf("/admin") !== -1) return ROLES.admin;
    if (path.indexOf("/staff") !== -1) return ROLES.staff;
    return ROLES.student;
  }

  /* ------------------------------------------------------------------ */
  /* JWT helpers                                                         */
  /* ------------------------------------------------------------------ */
  function decodeJwt(token) {
    try {
      var part = token.split(".")[1];
      if (!part) return null;
      var b64 = part.replace(/-/g, "+").replace(/_/g, "/");
      while (b64.length % 4) b64 += "=";
      return JSON.parse(decodeURIComponent(escape(global.atob(b64))));
    } catch (e) {
      return null;
    }
  }

  /* Only treat a token as dead when the JWT itself says so. */
  function jwtExpired(token) {
    var payload = decodeJwt(token);
    if (!payload || !payload.exp) return false;
    return payload.exp * 1000 <= Date.now();
  }

  /* ------------------------------------------------------------------ */
  /* Session factory                                                     */
  /* ------------------------------------------------------------------ */
  function createSession(roleName) {
    var cfg = resolveRole(roleName);

    var api = {
      role: cfg.key,
      config: cfg,

      getToken: function () {
        return read(cfg.tokenKey);
      },

      getUser: function () {
        return parseJSON(read(cfg.userKey));
      },

      /**
       * Synchronous validity check. Runs before paint, hits no network.
       * A session is valid when a token exists and the JWT has not expired.
       */
      isValid: function () {
        var token = read(cfg.tokenKey);
        if (!token) return false;
        if (jwtExpired(token)) return false;

        var expiry = parseInt(read(cfg.expiryKey), 10);
        if (expiry && Date.now() > expiry) return false;
        return true;
      },

      /** Persist a login response. Accepts any of the API payload shapes. */
      save: function (payload) {
        if (!payload) return false;
        var token = payload.access_token || payload.token;
        if (!token) return false;

        var user =
          payload[cfg.userField] ||
          payload.user ||
          payload.student ||
          payload.staff ||
          payload.admin ||
          null;

        var ttl = payload.expires_in
          ? payload.expires_in * 1000
          : DEFAULT_TTL_MS;

        write(cfg.tokenKey, token);
        write(cfg.expiryKey, String(Date.now() + ttl));
        if (user) write(cfg.userKey, JSON.stringify(user));
        return true;
      },

      updateUser: function (patch) {
        var user = api.getUser() || {};
        Object.keys(patch || {}).forEach(function (k) {
          user[k] = patch[k];
        });
        write(cfg.userKey, JSON.stringify(user));
        return user;
      },

      /** Sliding expiry - called on activity so an active user never expires. */
      touch: function () {
        if (!read(cfg.tokenKey)) return;
        var token = read(cfg.tokenKey);
        var payload = decodeJwt(token);
        // Never extend past the token's own expiry.
        var cap = payload && payload.exp ? payload.exp * 1000 : null;
        var next = Date.now() + DEFAULT_TTL_MS;
        write(cfg.expiryKey, String(cap ? Math.min(cap, next) : next));
      },

      clear: function () {
        remove(cfg.tokenKey);
        remove(cfg.userKey);
        remove(cfg.expiryKey);
        remove(cfg.lastPageKey);
      },

      /* -------------------------------------------------------------- */
      /* Page memory - refresh returns you to the same page              */
      /* -------------------------------------------------------------- */
      rememberPage: function () {
        if (!api.isValid()) return;
        var here =
          global.location.pathname +
          global.location.search +
          global.location.hash;
        write(cfg.lastPageKey, here);
      },

      getLastPage: function () {
        return read(cfg.lastPageKey);
      },

      /** Where to send the user after a successful login. */
      resumeTarget: function () {
        var params = new URLSearchParams(global.location.search);
        var next = params.get("next");
        if (next && next.charAt(0) === "/") return next;
        var last = read(cfg.lastPageKey);
        if (last && last.indexOf(cfg.loginPage) === -1) return last;
        return cfg.homePage;
      },

      loginUrl: function (includeNext) {
        if (!includeNext) return cfg.loginPage;
        var here =
          global.location.pathname +
          global.location.search +
          global.location.hash;
        return cfg.loginPage + "?next=" + encodeURIComponent(here);
      },

      /** Explicit sign-out. This is the ONLY path that destroys a session. */
      logout: function () {
        api.clear();
        global.location.replace(cfg.loginPage);
      },

      /* -------------------------------------------------------------- */
      /* Authenticated fetch                                             */
      /* -------------------------------------------------------------- */
      authFetch: function (path, options) {
        options = options || {};
        var headers = new Headers(options.headers || {});
        var token = api.getToken();
        if (token) headers.set("Authorization", "Bearer " + token);
        if (
          options.body &&
          !(options.body instanceof FormData) &&
          !headers.has("Content-Type")
        ) {
          headers.set("Content-Type", "application/json");
        }

        var url =
          path.indexOf("http") === 0 ? path : BASE_URL + path;

        return fetch(url, Object.assign({}, options, { headers: headers })).then(
          function (res) {
            if (res.status === 401) {
              // A confirmed rejection from the server. Sign out cleanly.
              api.clear();
              global.location.replace(api.loginUrl(true));
            } else {
              api.touch();
            }
            return res;
          }
        );
        // Network failures intentionally reject to the caller WITHOUT
        // clearing the session. Being offline must not log anyone out.
      },

      /**
       * Background revalidation. Never blocks rendering, never logs the user
       * out for anything other than an explicit 401/403.
       */
      revalidate: function () {
        var token = api.getToken();
        if (!token) return Promise.resolve(false);

        return fetch(BASE_URL + cfg.meEndpoint, {
          headers: { Authorization: "Bearer " + token }
        })
          .then(function (res) {
            if (res.status === 401 || res.status === 403) {
              api.clear();
              global.location.replace(api.loginUrl(true));
              return false;
            }
            if (!res.ok) return true; // 5xx / cold start - keep the session
            return res.json().then(function (data) {
              if (data && typeof data === "object") {
                write(cfg.userKey, JSON.stringify(data));
              }
              api.touch();
              return true;
            });
          })
          .catch(function () {
            // Offline or DNS failure. Keep the user signed in.
            return true;
          });
      },

      /** Guard used by protected pages. Returns true when allowed to render. */
      requireAuth: function () {
        if (api.isValid()) {
          api.rememberPage();
          api.revalidate();
          return true;
        }
        global.location.replace(api.loginUrl(true));
        return false;
      },

      /** Guard used by login pages - bounce an already-signed-in user home. */
      redirectIfAuthenticated: function () {
        if (api.isValid()) {
          global.location.replace(api.resumeTarget());
          return true;
        }
        return false;
      }
    };

    return api;
  }

  /* ------------------------------------------------------------------ */
  /* Wire up                                                             */
  /* ------------------------------------------------------------------ */
  var Session = createSession();

  Session.for = function (roleName) {
    return createSession(roleName);
  };

  global.Session = Session;
  global.createSession = createSession;

  // Backwards compatibility with the old global helper.
  global.apiFetch = function (path, options) {
    return Session.authFetch(path, options);
  };

  // Keep the session alive while the tab is in use.
  ["click", "keydown", "visibilitychange"].forEach(function (evt) {
    global.addEventListener(
      evt,
      function () {
        Session.touch();
      },
      { passive: true }
    );
  });

  // Record the current page so a refresh lands in the same place.
  global.addEventListener("pageshow", function () {
    Session.rememberPage();
  });
  global.addEventListener("beforeunload", function () {
    Session.rememberPage();
  });

  // Sign-out in one tab signs out the others; a login elsewhere is adopted.
  global.addEventListener("storage", function (e) {
    if (!e) return;
    if (e.key === Session.config.tokenKey && !e.newValue) {
      global.location.replace(Session.config.loginPage);
    }
  });
})(window);
