/**
 * Pre-paint auth guard. MUST be loaded in <head>, before any stylesheet
 * or body content, and BEFORE session.js is needed for rendering.
 *
 * Why this exists:
 * The login page used to flash on every refresh because the auth check ran
 * after the DOM had already painted. The sequence was:
 *   paint dashboard -> run check -> redirect -> paint login
 * Anything in between was visible as a flash.
 *
 * This guard runs synchronously in <head>, before the first paint:
 *   1. Reads the token straight from localStorage (no network, no await).
 *   2. If the session is valid, it marks the document ready and the page
 *      paints once, normally. No redirect, no flash, refresh keeps you on
 *      the exact same page.
 *   3. If there is no session, it redirects with location.replace BEFORE
 *      anything paints, so the protected page is never briefly visible.
 *
 * The document is hidden by an inline style until the decision is made, so
 * neither outcome produces a flash of the wrong screen.
 */
(function () {
  "use strict";

  var doc = document;
  var el = doc.documentElement;

  // Page declares what it needs via <script data-role="staff" data-guard="protected">
  var current = doc.currentScript || (function () {
    var all = doc.getElementsByTagName("script");
    return all[all.length - 1];
  })();

  var role = (current && current.getAttribute("data-role")) || "student";
  var mode = (current && current.getAttribute("data-guard")) || "protected";

  var CONFIG = {
    student: {
      tokenKey: "student_token",
      expiryKey: "student_token_expiry",
      lastPageKey: "student_last_page",
      loginPage: "login.html",
      homePage: "student-dashboard.html"
    },
    staff: {
      tokenKey: "staff_token",
      expiryKey: "staff_token_expiry",
      lastPageKey: "staff_last_page",
      loginPage: "index.html",
      homePage: "staff-dashboard.html"
    },
    admin: {
      tokenKey: "admin_token",
      expiryKey: "admin_token_expiry",
      lastPageKey: "admin_last_page",
      loginPage: "index.html",
      homePage: "admin-dashboard.html"
    }
  };

  var cfg = CONFIG[role] || CONFIG.student;

  // Expose the role so session.js picks the same one.
  window.SESSION_ROLE = role;

  function get(key) {
    try {
      return window.localStorage.getItem(key);
    } catch (e) {
      return null;
    }
  }

  function jwtAlive(token) {
    try {
      var part = token.split(".")[1];
      if (!part) return true;
      var b64 = part.replace(/-/g, "+").replace(/_/g, "/");
      while (b64.length % 4) b64 += "=";
      var payload = JSON.parse(window.atob(b64));
      if (!payload || !payload.exp) return true;
      return payload.exp * 1000 > Date.now();
    } catch (e) {
      // Unreadable token: let the server decide, do not log the user out here.
      return true;
    }
  }

  function hasSession() {
    var token = get(cfg.tokenKey);
    if (!token) return false;
    if (!jwtAlive(token)) return false;
    var expiry = parseInt(get(cfg.expiryKey), 10);
    if (expiry && Date.now() > expiry) return false;
    return true;
  }

  function reveal() {
    el.setAttribute("data-auth", "ready");
  }

  // Hide until resolved. Removed again the moment we decide to render.
  el.setAttribute("data-auth", "pending");

  var style = doc.createElement("style");
  style.setAttribute("data-auth-guard", "");
  style.appendChild(
    doc.createTextNode(
      "html[data-auth='pending'] body{visibility:hidden!important;}" +
        "html[data-auth='ready'] body{visibility:visible;}"
    )
  );
  (doc.head || el).appendChild(style);

  // Safety net: never leave the page permanently blank if something throws.
  setTimeout(reveal, 3000);

  var authed = hasSession();

  if (mode === "protected") {
    if (authed) {
      // Valid session. Render this page immediately - refresh stays put.
      try {
        window.localStorage.setItem(
          cfg.lastPageKey,
          window.location.pathname + window.location.search + window.location.hash
        );
      } catch (e) {}
      reveal();
    } else {
      // Redirect before the first paint so nothing flashes.
      var here =
        window.location.pathname + window.location.search + window.location.hash;
      window.location.replace(cfg.loginPage + "?next=" + encodeURIComponent(here));
    }
  } else if (mode === "guest") {
    // Login pages: send an already-signed-in user straight to where they were.
    if (authed) {
      var next = null;
      try {
        var params = new URLSearchParams(window.location.search);
        next = params.get("next");
        if (!next) {
          var last = window.localStorage.getItem(cfg.lastPageKey);
          if (last && last.indexOf(cfg.loginPage) === -1) next = last;
        }
      } catch (e) {}
      window.location.replace(next || cfg.homePage);
    } else {
      reveal();
    }
  } else {
    reveal();
  }

  // Always reveal once the DOM is in place, in case of an unexpected path.
  doc.addEventListener("DOMContentLoaded", function () {
    if (el.getAttribute("data-auth") === "pending" && mode !== "protected") {
      reveal();
    }
  });
})();
